import Feedback from './components/Feedback';
import HeritageMap from './components/HeritageMap'
import './App.css'

function App() {
  return (
    <>
      <header>
        <h1>Heritage Portal</h1>
        <p>Discover India's Historical and Cultural Heritage</p>
      </header>

      <main>
        <HeritageMap />
        <Feedback />
      </main>
    </>
  )
}

export default App