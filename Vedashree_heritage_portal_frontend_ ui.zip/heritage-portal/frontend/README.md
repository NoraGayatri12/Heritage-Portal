# Virasat – Heritage Portal frontend

## Member 1 scope
- Responsive home page and navigation/footer
- Login and registration UI (frontend demo only)
- Heritage discovery cards with search and category filter
- Existing interactive Leaflet heritage map and feedback component retained

## Run locally
1. Install Node.js (LTS).
2. Open a terminal in `frontend`.
3. Run `npm install`.
4. Run `npm run dev` and open the local URL printed by Vite.

## Important implementation note
Authentication in this task is a UI prototype using browser `localStorage`. It is not secure production authentication: passwords are stored locally in plain text. Connect the forms to your team's backend/API and use server-side password hashing, validation, sessions/JWT and authorization before deployment. Feedback currently shows a local success message and also needs a backend endpoint for persistent submissions.
