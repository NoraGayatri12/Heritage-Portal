import { useState } from 'react';
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  Circle,
  useMap
} from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const heritageSites = [
  // Maharashtra
  { name: 'Shaniwar Wada', city: 'Pune', category: 'Fort', position: [18.5196, 73.8553] },
  { name: 'Gateway of India', city: 'Mumbai', category: 'Monument', position: [18.9220, 72.8347] },
  { name: 'Raigad Fort', city: 'Raigad', category: 'Fort', position: [18.2345, 73.4420] },
  { name: 'Ajanta Caves', city: 'Aurangabad', category: 'Caves', position: [20.5519, 75.7033] },
  { name: 'Ellora Caves', city: 'Aurangabad', category: 'Caves', position: [20.0268, 75.1770] },

  // Delhi
  { name: 'Red Fort', city: 'Delhi', category: 'Fort', position: [28.6562, 77.2410] },
  { name: 'Qutub Minar', city: 'Delhi', category: 'Monument', position: [28.5245, 77.1855] },
  { name: 'India Gate', city: 'Delhi', category: 'Monument', position: [28.6129, 77.2295] },

  // Uttar Pradesh
  { name: 'Taj Mahal', city: 'Agra', category: 'Monument', position: [27.1751, 78.0421] },
  { name: 'Fatehpur Sikri', city: 'Agra', category: 'Monument', position: [27.0945, 77.6679] },

  // Rajasthan
  { name: 'Hawa Mahal', city: 'Jaipur', category: 'Monument', position: [26.9239, 75.8267] },
  { name: 'Amer Fort', city: 'Jaipur', category: 'Fort', position: [26.9855, 75.8513] },

  // Karnataka
  { name: 'Mysore Palace', city: 'Mysuru', category: 'Monument', position: [12.3052, 76.6552] },
  { name: 'Hampi', city: 'Vijayanagara', category: 'Monument', position: [15.3350, 76.4600] },

  // Telangana
  { name: 'Charminar', city: 'Hyderabad', category: 'Monument', position: [17.3616, 78.4747] },

  // Odisha
  { name: 'Konark Sun Temple', city: 'Konark', category: 'Monument', position: [19.8876, 86.0945] },

  // West Bengal
  { name: 'Victoria Memorial', city: 'Kolkata', category: 'Monument', position: [22.5448, 88.3426] },

  // Punjab
  { name: 'Golden Temple', city: 'Amritsar', category: 'Monument', position: [31.6200, 74.8765] },

  // Tamil Nadu
  { name: 'Mahabalipuram', city: 'Mahabalipuram', category: 'Monument', position: [12.6208, 80.1945] }
];

const heritageIcon = new L.Icon({
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

function RecenterMap({ position }) {
  const map = useMap();

  if (position) {
    map.flyTo(position, 10);
  }

  return null;
}

function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) ** 2;

  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function HeritageMap() {
  const [userLocation, setUserLocation] = useState(null);
  const [nearbySites, setNearbySites] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCity, setSelectedCity] = useState('All');
const [selectedCategory, setSelectedCategory] = useState('All');

const filteredSites = heritageSites.filter((site) => {
  const matchesSearch =
  site.name.toLowerCase().includes(searchTerm.trim().toLowerCase()) ||
  site.city.toLowerCase().includes(searchTerm.trim().toLowerCase());

  const matchesCity =
    selectedCity === 'All' || site.city === selectedCity;

  const matchesCategory =
  selectedCategory === 'All' || site.category === selectedCategory;

return matchesSearch && matchesCity && matchesCategory;
});

  const findNearbyPlaces = () => {
    setLoading(true);
    setError('');

    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userPos = [
          position.coords.latitude,
          position.coords.longitude
        ];

        setUserLocation(userPos);

        const nearby = heritageSites
          .map(site => ({
            ...site,
            distance: calculateDistance(
              userPos[0],
              userPos[1],
              site.position[0],
              site.position[1]
            )
          }))
          .filter(site => site.distance <= 25)
          .sort((a, b) => a.distance - b.distance);

        setNearbySites(nearby);
        setLoading(false);
      },
      () => {
        setError('Location access denied. Please allow location permission.');
        setLoading(false);
      }
    );
  };

  return (
    <div className="heritage-map-section">

      <h2>Explore Heritage Places Near You</h2>
      <div className="heritage-search">
  <input
    type="text"
    placeholder="Search heritage places..."
    value={searchTerm}
    onChange={(e) => setSearchTerm(e.target.value)}
  />

  <select
  value={selectedCity}
  onChange={(e) => setSelectedCity(e.target.value)}
>
  <option value="All">All Cities</option>
  {[...new Set(heritageSites.map(site => site.city))].sort().map(city => (
    <option key={city} value={city}>{city}</option>
  ))}
</select>
</div>


      <button onClick={findNearbyPlaces} disabled={loading}>
        {loading ? 'Finding Places...' : '📍 Find Nearby Places'}
      </button>

      {error && <p>{error}</p>}

      {userLocation && (
        <p>
          Your location detected successfully!
          Nearby heritage places within 25 km:
          {nearbySites.length}
        </p>
      )}

      <MapContainer
        center={[19.7515, 75.7139]}
        zoom={6}
        style={{
          height: '500px',
          width: '100%',
          marginTop: '20px'
        }}
      >

        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {userLocation && (
          <>
            <RecenterMap position={userLocation} />

            <Marker position={userLocation}>
              <Popup>You are here!</Popup>
            </Marker>

            <Circle
              center={userLocation}
              radius={25000}
              pathOptions={{
                color: 'blue',
                fillColor: '#3388ff',
                fillOpacity: 0.15
              }}
            />
          </>
        )}

        {filteredSites.map((site, index) => (
          <Marker
            key={index}
            position={site.position}
            icon={heritageIcon}
          >
            <Popup>
              <strong>{site.name}</strong>
              <br />
              {site.city}
              <br />
<a
  href={`https://www.google.com/maps/dir/?api=1&destination=${site.position[0]},${site.position[1]}`}
  target="_blank"
  rel="noopener noreferrer"
>
  Get Directions
</a>
            </Popup>
          </Marker>
        ))}

      </MapContainer>

      {userLocation && (
        <div>
          <h3>Nearby Heritage Places</h3>

          {nearbySites.length > 0 ? (
            nearbySites.map((site, index) => (
              <p key={index}>
                {site.name} – {site.distance.toFixed(2)} km away
              </p>
            ))
          ) : (
            <p>No heritage places found within 25 km.</p>
          )}
        </div>
      )}

    </div>
  );
}

export default HeritageMap;
