import { useState } from 'react';
import './Feedback.css';

function Feedback() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [rating, setRating] = useState(0);
  const [category, setCategory] = useState('Website Experience');
  const [message, setMessage] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (rating === 0) {
      alert('Please select a star rating.');
      return;
    }

    setSuccess('Thank you! Your feedback has been submitted.');
    setName('');
    setEmail('');
    setRating(0);
    setCategory('Website Experience');
    setMessage('');
  };

  return (
    <div className="feedback-container">
      <h2>Share Your Feedback</h2>
      <p>Help us improve your Heritage Portal experience.</p>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />

        <input
          type="email"
          placeholder="Your Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <label>Rate Your Experience</label>

        <div className="star-rating">
          {[1, 2, 3, 4, 5].map((star) => (
            <span
              key={star}
              onClick={() => setRating(star)}
              className={star <= rating ? 'active' : ''}
            >
              ★
            </span>
          ))}
        </div>

        <label>Feedback Category</label>

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option>Website Experience</option>
          <option>Interactive Map</option>
          <option>Heritage Information</option>
          <option>Suggestions</option>
          <option>Other</option>
        </select>

        <textarea
          placeholder="Write your feedback here..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows="5"
          required
        />

        <button type="submit">Submit Feedback</button>
      </form>

      {success && <p className="success-message">{success}</p>}
    </div>
  );
}

export default Feedback;