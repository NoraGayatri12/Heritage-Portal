import { useMemo, useState } from 'react';
import HeritageMap from './components/HeritageMap';
import Feedback from './components/Feedback';
import './App.css';

const sites = [
  { name:'Taj Mahal', place:'Agra, Uttar Pradesh', category:'Monument', era:'17th century', image:'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1000&q=85', description:'A marble masterpiece built by Emperor Shah Jahan, celebrated as a symbol of love and Mughal artistry.' },
  { name:'Hampi', place:'Vijayanagara, Karnataka', category:'Ancient City', era:'14th–16th century', image:'https://images.unsplash.com/photo-1600100397608-f010a8f6d7a9?auto=format&fit=crop&w=1000&q=85', description:'Explore the remarkable ruins, temples and stone architecture of the Vijayanagara Empire.' },
  { name:'Ajanta Caves', place:'Chhatrapati Sambhajinagar, Maharashtra', category:'Cave Complex', era:'2nd century BCE–6th century CE', image:'https://images.unsplash.com/photo-1606293926075-69a00db36721?auto=format&fit=crop&w=1000&q=85', description:'Ancient Buddhist cave monuments known for their extraordinary murals and rock-cut architecture.' },
  { name:'Amer Fort', place:'Jaipur, Rajasthan', category:'Fort', era:'16th century', image:'https://images.unsplash.com/photo-1599661046827-dacff0c0f09a?auto=format&fit=crop&w=1000&q=85', description:'A hilltop fort blending Rajput and Mughal design, with grand courtyards and ornate halls.' }
];

function AuthPanel({ mode, onClose, onSwitch, onLogin }) {
  const [name,setName] = useState('');
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [notice,setNotice] = useState('');
  const submit = (e) => {
    e.preventDefault();
    const users = JSON.parse(localStorage.getItem('heritageUsers') || '[]');
    if (mode === 'register') {
      if (users.some(u => u.email === email)) { setNotice('An account with this email already exists.'); return; }
      users.push({name,email,password});
      localStorage.setItem('heritageUsers', JSON.stringify(users));
      localStorage.setItem('heritageUser', JSON.stringify({name,email}));
      onLogin({name,email});
    } else {
      const user = users.find(u => u.email === email && u.password === password);
      if (!user) { setNotice('Email or password is incorrect. Register first if you are new here.'); return; }
      localStorage.setItem('heritageUser', JSON.stringify({name:user.name,email:user.email}));
      onLogin({name:user.name,email:user.email});
    }
  };
  return <div className="auth-overlay" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}>
    <section className="auth-card">
      <button className="auth-close" onClick={onClose} aria-label="Close">×</button>
      <span className="eyebrow">THE HERITAGE PORTAL</span>
      <h2>{mode === 'register' ? 'Create your account' : 'Welcome back'}</h2>
      <p>{mode === 'register' ? 'Join a community preserving the stories of India.' : 'Continue exploring India’s living history.'}</p>
      <form onSubmit={submit}>
        {mode === 'register' && <label>Full name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" required /></label>}
        <label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required /></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" minLength="6" required /></label>
        <button className="btn btn-primary auth-submit" type="submit">{mode === 'register' ? 'Create account' : 'Log in'} <span>→</span></button>
      </form>
      {notice && <p className="auth-notice">{notice}</p>}
      <div className="auth-switch">{mode === 'register' ? 'Already have an account?' : 'New to the portal?'} <button onClick={()=>onSwitch(mode === 'register' ? 'login' : 'register')}>{mode === 'register' ? 'Log in' : 'Create account'}</button></div>
      <small className="demo-note">Demo authentication: accounts are stored in this browser only. Do not use a real password.</small>
    </section>
  </div>;
}

function App() {
  const [authMode,setAuthMode] = useState('');
  const [user,setUser] = useState(()=>JSON.parse(localStorage.getItem('heritageUser') || 'null'));
  const [search,setSearch] = useState('');
  const [category,setCategory] = useState('All');
  const [activeSite,setActiveSite] = useState(null);
  const filtered = useMemo(()=>sites.filter(s=>(s.name+' '+s.place).toLowerCase().includes(search.toLowerCase()) && (category==='All'||s.category===category)),[search,category]);
  const login = u => { setUser(u); setAuthMode(''); };
  const logout = () => { localStorage.removeItem('heritageUser'); setUser(null); };
  return <div className="site-shell">
    <header className="navbar">
      <a className="brand" href="#home"><span className="brand-mark">✳</span><span>VIRASAT<small>INDIA'S HERITAGE PORTAL</small></span></a>
      <nav className="nav-links"><a href="#home">Home</a><a href="#explore">Explore</a><a href="#map">Heritage map</a><a href="#about">Our story</a><a href="#feedback">Feedback</a></nav>
      <div className="nav-actions">{user ? <><span className="welcome-user">Hi, {user.name.split(' ')[0]}</span><button className="btn btn-outline" onClick={logout}>Log out</button></> : <><button className="login-link" onClick={()=>setAuthMode('login')}>Log in</button><button className="btn btn-primary nav-join" onClick={()=>setAuthMode('register')}>Join the journey <span>↗</span></button></>}</div>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="hero-shade"></div>
        <div className="hero-content">
          <span className="hero-kicker"><i></i> A JOURNEY THROUGH TIME</span>
          <h1>Every stone has<br/>a <em>story</em> to tell.</h1>
          <p>Discover the places, people and traditions that have shaped the incredible story of India.</p>
          <div className="hero-actions"><a className="btn btn-light" href="#explore">Explore heritage <span>↗</span></a><a className="text-link" href="#about">Discover our mission <span>→</span></a></div>
          <div className="hero-footnote"><span>01 / 04</span><span className="hero-line"></span><span>THE STORIES THAT SHAPE US</span></div>
        </div>
        <div className="hero-caption">TAJ MAHAL · AGRA, INDIA</div>
      </section>

      <section className="intro-strip" id="about"><div className="section-kicker">OUR SHARED LEGACY</div><p>India is not just a place on the map. It is <em>thousands of years</em> of stories, carved in stone, woven in culture and carried by generations.</p><span className="intro-symbol">✳</span></section>

      <section className="explore-section section-wrap" id="explore">
        <div className="section-heading"><div><span className="section-kicker">CURATED DISCOVERIES</span><h2>Explore the extraordinary.</h2><p>Start with a landmark. Leave with a thousand stories.</p></div><span className="heading-index">01 — 04</span></div>
        <div className="explore-tools"><label className="search-box"><span>⌕</span><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search a place or destination..." /></label><select value={category} onChange={e=>setCategory(e.target.value)} aria-label="Filter by category"><option>All</option><option>Monument</option><option>Ancient City</option><option>Cave Complex</option><option>Fort</option></select></div>
        <div className="site-grid">{filtered.map((site,i)=><article className="site-card" key={site.name} onClick={()=>setActiveSite(site)} tabIndex="0" onKeyDown={e=>e.key==='Enter'&&setActiveSite(site)}><div className="site-image"><img src={site.image} alt={site.name}/><span className="site-number">0{i+1}</span><span className="site-arrow">↗</span></div><div className="site-meta"><span>{site.category}</span><span>{site.era}</span></div><h3>{site.name}</h3><p>{site.place}</p></article>)}
          {filtered.length===0 && <p className="empty-state">No matching places. Try another search, intrepid explorer.</p>}
        </div>
      </section>

      <section className="map-band" id="map"><div className="map-band-copy"><span className="section-kicker">FIND YOUR WAY THROUGH HISTORY</span><h2>Heritage is closer<br/>than you think.</h2><p>Explore historic places across India, discover what is around you and plan your next journey.</p><a href="#interactive-map" className="map-cta">Explore the interactive map <span>↗</span></a></div><div className="map-band-art"><span className="map-orbit orbit-one"></span><span className="map-orbit orbit-two"></span><span className="map-pin">✳</span><span className="map-label">20° N · 78° E</span></div></section>
      <section className="map-section section-wrap" id="interactive-map"><div className="section-heading"><div><span className="section-kicker">DISCOVER BY LOCATION</span><h2>Explore the map.</h2><p>Search, filter and find heritage landmarks across the country.</p></div></div><HeritageMap /></section>

      <section className="community-section"><div><span className="section-kicker">PRESERVE WHAT MATTERS</span><h2>Have a story<br/>worth sharing?</h2><p>Help keep our heritage alive. Share a place, a memory or a piece of history with the community.</p></div><button className="btn btn-light" onClick={()=>setAuthMode(user?'register':'login')}>Be part of the story <span>↗</span></button></section>
      <section id="feedback" className="feedback-section"><div className="section-heading"><div><span className="section-kicker">YOUR VOICE MATTERS</span><h2>Help us do better.</h2><p>Every suggestion helps us tell India's stories more thoughtfully.</p></div></div><Feedback /></section>
    </main>

    <footer className="footer"><a className="brand footer-brand" href="#home"><span className="brand-mark">✳</span><span>VIRASAT<small>INDIA'S HERITAGE PORTAL</small></span></a><p>Honouring the past. Inspiring the future.</p><div className="footer-links"><a href="#home">Home</a><a href="#explore">Explore</a><a href="#map">Map</a><a href="#feedback">Feedback</a></div><small>© 2026 Virasat Heritage Portal. Made to preserve stories.</small></footer>

    {authMode && <AuthPanel mode={authMode} onClose={()=>setAuthMode('')} onSwitch={setAuthMode} onLogin={login}/>}
    {activeSite && <div className="detail-overlay" onMouseDown={e=>e.target===e.currentTarget&&setActiveSite(null)}><article className="detail-card"><button className="detail-close" onClick={()=>setActiveSite(null)}>×</button><img src={activeSite.image} alt={activeSite.name}/><div className="detail-copy"><span className="section-kicker">{activeSite.category} · {activeSite.era}</span><h2>{activeSite.name}</h2><p className="detail-place">{activeSite.place}</p><p>{activeSite.description}</p><a className="btn btn-primary" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(activeSite.name+' '+activeSite.place)}`}>View location ↗</a></div></article></div>}
  </div>;
}
export default App;
